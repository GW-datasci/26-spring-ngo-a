import { Routes, Route, Navigate } from 'react-router-dom'
import Nav from './components/Nav'
import Explore from './pages/Explore'
import Member from './pages/Member'

export default function App() {
  return (
    <div style={{ minHeight: '100vh', display: 'flex', flexDirection: 'column' }}>
      <Nav />
      <main style={{ flex: 1 }}>
        <Routes>
          <Route path="/" element={<Navigate to="/explore" replace />} />
          <Route path="/explore" element={<Explore />} />
          <Route path="/member/:handle" element={<Member />} />
        </Routes>
      </main>
    </div>
  )
}
