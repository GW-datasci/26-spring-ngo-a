import {
  RadarChart, Radar, PolarGrid, PolarAngleAxis, ResponsiveContainer,
} from 'recharts'
import { PARTY_COLOR } from '../hooks/useMembers'

const EMOTIONS = [
  { key: 'avg_anger',   label: 'Anger' },
  { key: 'avg_fear',    label: 'Fear' },
  { key: 'avg_disgust', label: 'Disgust' },
  { key: 'avg_sadness', label: 'Sadness' },
  { key: 'avg_joy',     label: 'Joy' },
]

export default function EmotionRadar({ member }) {
  const color = PARTY_COLOR[member.party_code] ?? '#888'

  const data = EMOTIONS.map(({ key, label }) => ({
    emotion: label,
    value: member[key] ?? 0,
  }))

  return (
    <div>
      <h3 style={{
        fontFamily: 'DM Serif Display, serif',
        fontSize: '16px',
        color: 'var(--text-primary)',
        marginBottom: '16px',
        fontWeight: 400,
      }}>
        Emotional Tone
      </h3>
      <ResponsiveContainer width="100%" height={260}>
        <RadarChart data={data} margin={{ top: 10, right: 30, bottom: 10, left: 30 }}>
          <PolarGrid stroke="var(--border)" />
          <PolarAngleAxis
            dataKey="emotion"
            tick={{ fill: 'var(--text-secondary)', fontSize: 12, fontFamily: 'DM Sans' }}
          />
          <Radar
            dataKey="value"
            stroke={color}
            fill={color}
            fillOpacity={0.2}
            strokeWidth={2}
          />
        </RadarChart>
      </ResponsiveContainer>

      {/* Emotion bar breakdown */}
      <div style={{ display: 'flex', flexDirection: 'column', gap: '8px', marginTop: '8px' }}>
        {EMOTIONS.sort((a, b) => (member[b.key] ?? 0) - (member[a.key] ?? 0)).map(({ key, label }) => {
          const val = member[key] ?? 0
          return (
            <div key={key} style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
              <span style={{
                width: '60px',
                fontSize: '12px',
                color: 'var(--text-secondary)',
                textAlign: 'right',
                fontFamily: 'DM Sans',
              }}>
                {label}
              </span>
              <div style={{
                flex: 1,
                height: '6px',
                background: 'var(--border)',
                borderRadius: '3px',
                overflow: 'hidden',
              }}>
                <div style={{
                  width: `${(val * 100).toFixed(1)}%`,
                  height: '100%',
                  background: color,
                  opacity: 0.8,
                  borderRadius: '3px',
                  transition: 'width 0.4s ease',
                }} />
              </div>
              <span style={{
                width: '44px',
                fontSize: '11px',
                fontFamily: 'JetBrains Mono, monospace',
                color: 'var(--text-secondary)',
              }}>
                {(val * 100).toFixed(1)}%
              </span>
            </div>
          )
        })}
      </div>
    </div>
  )
}
