import { NavLink } from 'react-router-dom'

export default function Nav() {
  return (
    <nav style={{
      background: 'var(--surface)',
      borderBottom: '1px solid var(--border)',
      padding: '0 32px',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      height: '56px',
      position: 'sticky',
      top: 0,
      zIndex: 100,
    }}>
      <div style={{ display: 'flex', alignItems: 'baseline', gap: '10px' }}>
        <span style={{
          fontFamily: 'DM Serif Display, serif',
          fontSize: '18px',
          color: 'var(--text-primary)',
          letterSpacing: '-0.3px',
        }}>
          Congress on Twitter
        </span>
        <span style={{
          fontSize: '11px',
          color: 'var(--text-muted)',
          fontFamily: 'JetBrains Mono, monospace',
          textTransform: 'uppercase',
          letterSpacing: '0.5px',
        }}>
          118th Congress
        </span>
      </div>

      <div style={{ display: 'flex', gap: '4px' }}>
        {[
          { to: '/explore', label: 'Explore' },
        ].map(({ to, label }) => (
          <NavLink
            key={to}
            to={to}
            style={({ isActive }) => ({
              padding: '6px 14px',
              borderRadius: '6px',
              fontSize: '13px',
              fontWeight: 500,
              textDecoration: 'none',
              color: isActive ? 'var(--gold)' : 'var(--text-secondary)',
              background: isActive ? 'var(--gold-dim)' : 'transparent',
              transition: 'all 0.15s',
            })}
          >
            {label}
          </NavLink>
        ))}
      </div>
    </nav>
  )
}
