import { useMemo, useState, useCallback } from 'react'
import {
  ScatterChart, Scatter, XAxis, YAxis, ZAxis,
  Tooltip, ResponsiveContainer, ReferenceLine,
} from 'recharts'
import { useNavigate } from 'react-router-dom'
import { PARTY_COLOR, X_AXIS_OPTIONS } from '../hooks/useMembers'

const fmt = (v, decimals = 1) =>
  v == null ? '—' : Number(v).toLocaleString(undefined, { maximumFractionDigits: decimals })

function CustomTooltip({ active, payload }) {
  if (!active || !payload?.length) return null
  const d = payload[0]?.payload
  if (!d) return null
  const color = PARTY_COLOR[d.party_code] ?? '#888'

  return (
    <div className="custom-tooltip">
      <div className="name" style={{ color }}>
        {d.official_full}
      </div>
      <div style={{ fontSize: 11, color: 'var(--text-muted)', marginBottom: 8 }}>
        {d.state_abbrev} · {d.party_code === 'D' ? 'Democrat' : d.party_code === 'R' ? 'Republican' : 'Independent'}
      </div>
      <div className="metric"><span>Small donors</span><span>{fmt(d.pct_small_donors, 1)}%</span></div>
      <div className="metric"><span>Avg retweets</span><span>{fmt(d.avg_retweets_raw, 0)}</span></div>
      <div className="metric"><span>Outrage index</span><span>{fmt(d.outrage_index, 3)}</span></div>
      <div className="metric"><span>Avg sentiment</span><span>{fmt(d.avg_sentiment, 3)}</span></div>
      <div className="metric"><span>Ideology |DW|</span><span>{fmt(d.nominate_abs, 3)}</span></div>
      <div style={{ marginTop: 8, fontSize: 11, color: 'var(--text-muted)' }}>
        Click to view profile →
      </div>
    </div>
  )
}

export default function ScatterPlot({ members, xAxisKey = 'avg_retweets_raw', filters }) {
  const navigate = useNavigate()
  const [hovered, setHovered] = useState(null)

  const xOption = X_AXIS_OPTIONS.find(o => o.key === xAxisKey) ?? X_AXIS_OPTIONS[0]

  // Filter and prepare data
  const data = useMemo(() => {
    return members
      .filter(m => {
        if (m[xAxisKey] == null || m.pct_small_donors == null) return false
        if (filters.party.length && !filters.party.includes(m.party_code)) return false
        if (filters.quartile.length && !filters.quartile.includes(m.quartile)) return false
        if (filters.caucus) {
          if (!m[filters.caucus]) return false
        }
        return true
      })
      .map(m => ({
        ...m,
        x: m[xAxisKey],
        y: m.pct_small_donors,
        z: m.nominate_abs ?? 0.3,
      }))
  }, [members, xAxisKey, filters])

  // Split by party for separate Scatter series (so we get per-party colors)
  const byParty = useMemo(() => {
    const groups = {}
    for (const d of data) {
      const p = d.party_code ?? 'I'
      if (!groups[p]) groups[p] = []
      groups[p].push(d)
    }
    return groups
  }, [data])

  const handleClick = useCallback((point) => {
    if (point?.handle_lower) {
      navigate(`/member/${point.handle_lower}`)
    }
  }, [navigate])

  return (
    <div style={{ width: '100%', height: '100%' }}>
      <ResponsiveContainer width="100%" height="100%">
        <ScatterChart margin={{ top: 20, right: 30, bottom: 40, left: 20 }}>
          <XAxis
            type="number"
            dataKey="x"
            name={xOption.label}
            tick={{ fill: 'var(--text-secondary)', fontSize: 11, fontFamily: 'JetBrains Mono' }}
            tickLine={false}
            axisLine={{ stroke: 'var(--border)' }}
            label={{
              value: xOption.label,
              position: 'insideBottom',
              offset: -20,
              fill: 'var(--text-secondary)',
              fontSize: 12,
              fontFamily: 'DM Sans',
            }}
          />
          <YAxis
            type="number"
            dataKey="y"
            name="Small Donor %"
            tick={{ fill: 'var(--text-secondary)', fontSize: 11, fontFamily: 'JetBrains Mono' }}
            tickLine={false}
            axisLine={{ stroke: 'var(--border)' }}
            tickFormatter={v => `${v}%`}
            label={{
              value: 'Small Donor %',
              angle: -90,
              position: 'insideLeft',
              offset: 10,
              fill: 'var(--text-secondary)',
              fontSize: 12,
              fontFamily: 'DM Sans',
            }}
          />
          <ZAxis type="number" dataKey="z" range={[20, 120]} />
          <Tooltip
            content={<CustomTooltip />}
            cursor={{ stroke: 'var(--border-bright)', strokeWidth: 1 }}
          />

          {Object.entries(byParty).map(([party, pts]) => (
            <Scatter
              key={party}
              name={party}
              data={pts}
              fill={PARTY_COLOR[party] ?? '#888'}
              fillOpacity={0.7}
              stroke={PARTY_COLOR[party] ?? '#888'}
              strokeWidth={0}
              onClick={handleClick}
              style={{ cursor: 'pointer' }}
            />
          ))}
        </ScatterChart>
      </ResponsiveContainer>
    </div>
  )
}
