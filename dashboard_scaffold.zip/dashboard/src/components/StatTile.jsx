export default function StatTile({ label, value, sub, highlight }) {
  return (
    <div style={{
      background: 'var(--surface)',
      border: `1px solid ${highlight ? 'rgba(240,180,41,0.3)' : 'var(--border)'}`,
      borderRadius: '10px',
      padding: '16px 20px',
      background: highlight ? 'rgba(240,180,41,0.05)' : 'var(--surface)',
    }}>
      <div style={{
        fontSize: '11px',
        color: 'var(--text-muted)',
        textTransform: 'uppercase',
        letterSpacing: '0.6px',
        fontFamily: 'DM Sans',
        marginBottom: '6px',
      }}>
        {label}
      </div>
      <div style={{
        fontSize: '24px',
        fontFamily: 'JetBrains Mono, monospace',
        color: highlight ? 'var(--gold)' : 'var(--text-primary)',
        fontWeight: 500,
        lineHeight: 1,
      }}>
        {value}
      </div>
      {sub && (
        <div style={{
          fontSize: '11px',
          color: 'var(--text-secondary)',
          marginTop: '4px',
          fontFamily: 'DM Sans',
        }}>
          {sub}
        </div>
      )}
    </div>
  )
}
