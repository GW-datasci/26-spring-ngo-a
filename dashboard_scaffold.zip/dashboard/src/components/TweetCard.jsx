const fmt = n => n == null ? '—' : Number(n).toLocaleString()

function SentimentPill({ label }) {
  const colors = {
    positive: { bg: 'rgba(74,222,128,0.1)', color: '#4ade80', border: 'rgba(74,222,128,0.25)' },
    negative: { bg: 'rgba(248,113,113,0.1)', color: '#f87171', border: 'rgba(248,113,113,0.25)' },
    neutral:  { bg: 'rgba(107,127,163,0.1)', color: '#6b7fa3', border: 'rgba(107,127,163,0.25)' },
  }
  const s = colors[label] ?? colors.neutral
  return (
    <span style={{
      fontSize: '10px',
      fontFamily: 'JetBrains Mono, monospace',
      padding: '2px 8px',
      borderRadius: '10px',
      background: s.bg,
      color: s.color,
      border: `1px solid ${s.border}`,
      textTransform: 'uppercase',
      letterSpacing: '0.5px',
    }}>
      {label}
    </span>
  )
}

export default function TweetCard({ tweet }) {
  const date = tweet['Created At']
    ? new Date(tweet['Created At']).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })
    : null

  return (
    <div style={{
      background: 'var(--surface)',
      border: '1px solid var(--border)',
      borderRadius: '10px',
      padding: '14px 16px',
      transition: 'border-color 0.15s',
    }}
    onMouseEnter={e => e.currentTarget.style.borderColor = 'var(--border-bright)'}
    onMouseLeave={e => e.currentTarget.style.borderColor = 'var(--border)'}
    >
      <p style={{
        fontSize: '13px',
        lineHeight: '1.55',
        color: 'var(--text-primary)',
        margin: '0 0 10px 0',
        wordBreak: 'break-word',
      }}>
        {tweet.Text}
      </p>
      <div style={{
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        flexWrap: 'wrap',
        gap: '8px',
      }}>
        <div style={{ display: 'flex', gap: '14px', alignItems: 'center' }}>
          {tweet.label && <SentimentPill label={tweet.label} />}
          {date && (
            <span style={{ fontSize: '11px', color: 'var(--text-muted)', fontFamily: 'DM Sans' }}>
              {date}
            </span>
          )}
        </div>
        <div style={{ display: 'flex', gap: '14px' }}>
          <span style={{ fontSize: '11px', color: 'var(--text-secondary)', fontFamily: 'JetBrains Mono' }}>
            🔁 {fmt(tweet.Retweets)}
          </span>
          <span style={{ fontSize: '11px', color: 'var(--text-secondary)', fontFamily: 'JetBrains Mono' }}>
            ♥ {fmt(tweet.Likes)}
          </span>
        </div>
      </div>
    </div>
  )
}
