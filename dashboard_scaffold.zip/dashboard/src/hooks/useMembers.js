import { useState, useEffect, useMemo } from 'react'
import membersRaw from '../data/members.json'
import topTweetsRaw from '../data/top_tweets.json'

// Party display helpers
export const PARTY_LABEL = { D: 'Democrat', R: 'Republican', I: 'Independent' }
export const PARTY_COLOR = { D: '#4a8ff5', R: '#e8433a', I: '#a78bfa' }

// X-axis options for scatter plot
export const X_AXIS_OPTIONS = [
  { key: 'avg_retweets_raw', label: 'Avg Retweets (Virality)', format: v => v?.toFixed(0) },
  { key: 'outrage_index',    label: 'Outrage Index',           format: v => v?.toFixed(3) },
  { key: 'avg_sentiment',    label: 'Avg Sentiment',           format: v => v?.toFixed(3) },
  { key: 'avg_anger',        label: 'Avg Anger',               format: v => v?.toFixed(3) },
  { key: 'nominate_abs',     label: 'Ideological Extremism',   format: v => v?.toFixed(3) },
]

export function useMembers() {
  // Attach top tweets to each member
  const members = useMemo(() => {
    return membersRaw.map(m => ({
      ...m,
      top_tweets: topTweetsRaw[m.handle_lower] ?? [],
    }))
  }, [])

  return members
}

export function useMember(handle) {
  const members = useMembers()
  return useMemo(
    () => members.find(m => m.handle_lower === handle?.toLowerCase()),
    [members, handle]
  )
}

// Historical cycle columns in order
export const CYCLE_COLS = [
  { key: 'pct_small_2008', year: '2008' },
  { key: 'pct_small_2010', year: '2010' },
  { key: 'pct_small_2012', year: '2012' },
  { key: 'pct_small_2014', year: '2014' },
  { key: 'pct_small_2016', year: '2016' },
  { key: 'pct_small_2018', year: '2018' },
  { key: 'pct_small_2020', year: '2020' },
  { key: 'pct_small_2022', year: '2022' },
]

export function getCycleHistory(member) {
  return CYCLE_COLS
    .map(({ key, year }) => ({ year, value: member[key] }))
    .filter(d => d.value != null)
}

// Caucus membership labels
export const CAUCUS_FLAGS = [
  { key: 'is_freedom_caucus', label: 'Freedom Caucus' },
  { key: 'is_progressive',    label: 'Progressive Caucus' },
  { key: 'is_squad',          label: 'The Squad' },
  { key: 'is_problem_solver', label: 'Problem Solvers' },
  { key: 'is_blue_dog',       label: 'Blue Dog Coalition' },
  { key: 'is_new_dem',        label: 'New Democrat Coalition' },
  { key: 'is_rsc',            label: 'Republican Study Committee' },
]
