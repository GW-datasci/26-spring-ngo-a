import { useState, useMemo } from 'react'
import ScatterPlot from '../components/ScatterPlot'
import { useMembers, X_AXIS_OPTIONS, PARTY_COLOR, CAUCUS_FLAGS } from '../hooks/useMembers'

const QUARTILES = ['Q1 (lowest)', 'Q2', 'Q3', 'Q4 (highest)']

function FilterChip({ label, active, color, onClick }) {
  return (
    <button
      onClick={onClick}
      style={{
        padding: '5px 12px',
        borderRadius: '20px',
        fontSize: '12px',
        fontFamily: 'DM Sans, sans-serif',
        fontWeight: 500,
        cursor: 'pointer',
        border: `1px solid ${active ? (color ?? 'var(--gold)') : 'var(--border)'}`,
        background: active ? `${color ?? 'var(--gold)'}18` : 'transparent',
        color: active ? (color ?? 'var(--gold)') : 'var(--text-secondary)',
        transition: 'all 0.15s',
      }}
    >
      {label}
    </button>
  )
}

export default function Explore() {
  const members = useMembers()

  const [xAxisKey, setXAxisKey] = useState('avg_retweets_raw')
  const [filters, setFilters] = useState({
    party: [],      // [] = all
    quartile: [],   // [] = all
    caucus: null,   // null = all
  })

  const toggleParty = (p) =>
    setFilters(f => ({
      ...f,
      party: f.party.includes(p) ? f.party.filter(x => x !== p) : [...f.party, p],
    }))

  const toggleQuartile = (q) =>
    setFilters(f => ({
      ...f,
      quartile: f.quartile.includes(q) ? f.quartile.filter(x => x !== q) : [...f.quartile, q],
    }))

  const setCaucus = (key) =>
    setFilters(f => ({ ...f, caucus: f.caucus === key ? null : key }))

  // Visible count
  const visibleCount = useMemo(() => {
    return members.filter(m => {
      if (m[xAxisKey] == null || m.pct_small_donors == null) return false
      if (filters.party.length && !filters.party.includes(m.party_code)) return false
      if (filters.quartile.length && !filters.quartile.includes(m.quartile)) return false
      if (filters.caucus && !m[filters.caucus]) return false
      return true
    }).length
  }, [members, xAxisKey, filters])

  return (
    <div style={{ padding: '32px', maxWidth: '1400px', margin: '0 auto' }}>

      {/* Header */}
      <div style={{ marginBottom: '28px' }}>
        <h1 style={{
          fontFamily: 'DM Serif Display, serif',
          fontSize: '32px',
          fontWeight: 400,
          color: 'var(--text-primary)',
          margin: '0 0 8px 0',
          lineHeight: 1.15,
        }}>
          Twitter Virality & Small-Donor Funding
        </h1>
        <p style={{
          fontSize: '14px',
          color: 'var(--text-secondary)',
          margin: 0,
          maxWidth: '600px',
          lineHeight: 1.6,
        }}>
          Each point is a House member in the 118th Congress. Dot size reflects ideological
          extremism (|DW-NOMINATE|). Click any member to explore their profile.
        </p>
      </div>

      {/* Controls */}
      <div style={{
        display: 'flex',
        flexWrap: 'wrap',
        gap: '24px',
        alignItems: 'flex-start',
        marginBottom: '20px',
      }}>

        {/* X-axis selector */}
        <div>
          <div style={{ fontSize: '11px', color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.6px', marginBottom: '8px' }}>
            X Axis
          </div>
          <div style={{ display: 'flex', gap: '6px', flexWrap: 'wrap' }}>
            {X_AXIS_OPTIONS.map(opt => (
              <FilterChip
                key={opt.key}
                label={opt.label}
                active={xAxisKey === opt.key}
                onClick={() => setXAxisKey(opt.key)}
              />
            ))}
          </div>
        </div>

        {/* Party filter */}
        <div>
          <div style={{ fontSize: '11px', color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.6px', marginBottom: '8px' }}>
            Party
          </div>
          <div style={{ display: 'flex', gap: '6px' }}>
            {['D', 'R', 'I'].map(p => (
              <FilterChip
                key={p}
                label={{ D: 'Democrat', R: 'Republican', I: 'Independent' }[p]}
                active={filters.party.includes(p)}
                color={PARTY_COLOR[p]}
                onClick={() => toggleParty(p)}
              />
            ))}
          </div>
        </div>

        {/* Virality quartile filter */}
        <div>
          <div style={{ fontSize: '11px', color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.6px', marginBottom: '8px' }}>
            Virality Quartile
          </div>
          <div style={{ display: 'flex', gap: '6px', flexWrap: 'wrap' }}>
            {QUARTILES.map(q => (
              <FilterChip
                key={q}
                label={q}
                active={filters.quartile.includes(q)}
                onClick={() => toggleQuartile(q)}
              />
            ))}
          </div>
        </div>

        {/* Caucus filter */}
        <div>
          <div style={{ fontSize: '11px', color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.6px', marginBottom: '8px' }}>
            Caucus
          </div>
          <div style={{ display: 'flex', gap: '6px', flexWrap: 'wrap' }}>
            {CAUCUS_FLAGS.map(({ key, label }) => (
              <FilterChip
                key={key}
                label={label}
                active={filters.caucus === key}
                onClick={() => setCaucus(key)}
              />
            ))}
          </div>
        </div>
      </div>

      {/* Count */}
      <div style={{
        fontSize: '12px',
        color: 'var(--text-muted)',
        fontFamily: 'JetBrains Mono, monospace',
        marginBottom: '12px',
      }}>
        {visibleCount} members shown
      </div>

      {/* Chart */}
      <div style={{
        background: 'var(--surface)',
        border: '1px solid var(--border)',
        borderRadius: '12px',
        padding: '8px',
        height: '540px',
      }}>
        <ScatterPlot members={members} xAxisKey={xAxisKey} filters={filters} />
      </div>

      {/* Legend */}
      <div style={{
        display: 'flex',
        gap: '24px',
        marginTop: '16px',
        flexWrap: 'wrap',
        alignItems: 'center',
      }}>
        {['D', 'R', 'I'].map(p => (
          <div key={p} style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
            <div style={{
              width: '10px', height: '10px', borderRadius: '50%',
              background: PARTY_COLOR[p], opacity: 0.8,
            }} />
            <span style={{ fontSize: '12px', color: 'var(--text-secondary)' }}>
              {{ D: 'Democrat', R: 'Republican', I: 'Independent' }[p]}
            </span>
          </div>
        ))}
        <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>
            <div style={{ width: '6px', height: '6px', borderRadius: '50%', background: 'var(--text-muted)' }} />
            <div style={{ width: '10px', height: '10px', borderRadius: '50%', background: 'var(--text-muted)' }} />
            <div style={{ width: '14px', height: '14px', borderRadius: '50%', background: 'var(--text-muted)' }} />
          </div>
          <span style={{ fontSize: '12px', color: 'var(--text-secondary)' }}>
            Dot size = ideological extremism
          </span>
        </div>
      </div>
    </div>
  )
}
