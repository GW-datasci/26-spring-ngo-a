import { useParams, useNavigate } from 'react-router-dom'
import {
  LineChart, Line, XAxis, YAxis, Tooltip,
  ResponsiveContainer, ReferenceLine,
} from 'recharts'
import { useMember, PARTY_COLOR, CAUCUS_FLAGS, getCycleHistory } from '../hooks/useMembers'
import EmotionRadar from '../components/EmotionRadar'
import TweetCard from '../components/TweetCard'
import StatTile from '../components/StatTile'

const fmt = (v, decimals = 1, suffix = '') =>
  v == null ? '—' : `${Number(v).toLocaleString(undefined, { maximumFractionDigits: decimals })}${suffix}`

function Section({ title, children }) {
  return (
    <div>
      <h2 style={{
        fontFamily: 'DM Serif Display, serif',
        fontSize: '20px',
        fontWeight: 400,
        color: 'var(--text-primary)',
        margin: '0 0 16px 0',
      }}>
        {title}
      </h2>
      {children}
    </div>
  )
}

function CycleChart({ member }) {
  const data = getCycleHistory(member)
  if (!data.length) return <p style={{ color: 'var(--text-muted)', fontSize: 13 }}>No historical data available.</p>

  return (
    <ResponsiveContainer width="100%" height={180}>
      <LineChart data={data} margin={{ top: 8, right: 16, bottom: 8, left: 0 }}>
        <XAxis
          dataKey="year"
          tick={{ fill: 'var(--text-secondary)', fontSize: 11, fontFamily: 'JetBrains Mono' }}
          axisLine={{ stroke: 'var(--border)' }}
          tickLine={false}
        />
        <YAxis
          tick={{ fill: 'var(--text-secondary)', fontSize: 11, fontFamily: 'JetBrains Mono' }}
          axisLine={false}
          tickLine={false}
          tickFormatter={v => `${v}%`}
          width={40}
        />
        <Tooltip
          formatter={(v) => [`${v?.toFixed(1)}%`, 'Small Donor %']}
          contentStyle={{
            background: 'var(--surface-2, #1a2438)',
            border: '1px solid var(--border-bright)',
            borderRadius: '8px',
            fontFamily: 'JetBrains Mono',
            fontSize: '12px',
          }}
        />
        <ReferenceLine x="2018" stroke="var(--gold)" strokeDasharray="4 3" opacity={0.5} />
        <Line
          type="monotone"
          dataKey="value"
          stroke={PARTY_COLOR[member.party_code] ?? '#888'}
          strokeWidth={2}
          dot={{ r: 3, fill: PARTY_COLOR[member.party_code] ?? '#888' }}
          activeDot={{ r: 5 }}
        />
      </LineChart>
    </ResponsiveContainer>
  )
}

export default function Member() {
  const { handle } = useParams()
  const navigate = useNavigate()
  const member = useMember(handle)

  if (!member) {
    return (
      <div style={{ padding: '80px 32px', textAlign: 'center' }}>
        <p style={{ color: 'var(--text-secondary)', fontFamily: 'DM Sans' }}>
          Member <code style={{ fontFamily: 'JetBrains Mono' }}>@{handle}</code> not found.
        </p>
        <button
          onClick={() => navigate('/explore')}
          style={{
            marginTop: '16px', padding: '8px 20px', borderRadius: '8px',
            background: 'var(--surface)', border: '1px solid var(--border)',
            color: 'var(--text-secondary)', cursor: 'pointer', fontFamily: 'DM Sans',
          }}
        >
          ← Back to Explore
        </button>
      </div>
    )
  }

  const partyColor = PARTY_COLOR[member.party_code] ?? '#888'
  const partyLabel = { D: 'Democrat', R: 'Republican', I: 'Independent' }[member.party_code] ?? member.party_code
  const caucuses = CAUCUS_FLAGS.filter(({ key }) => member[key])

  const sentimentDir = member.sentiment_slope > 0.0001
    ? { label: 'Trending positive', color: '#4ade80' }
    : member.sentiment_slope < -0.0001
    ? { label: 'Trending negative', color: '#f87171' }
    : { label: 'Stable', color: 'var(--text-secondary)' }

  return (
    <div style={{ padding: '32px', maxWidth: '1200px', margin: '0 auto' }}>

      {/* Back */}
      <button
        onClick={() => navigate('/explore')}
        style={{
          background: 'none', border: 'none', color: 'var(--text-secondary)',
          cursor: 'pointer', fontFamily: 'DM Sans', fontSize: '13px',
          padding: 0, marginBottom: '24px', display: 'flex', alignItems: 'center', gap: '6px',
        }}
      >
        ← Back to Explore
      </button>

      {/* Member header */}
      <div style={{ display: 'flex', alignItems: 'flex-start', gap: '16px', marginBottom: '32px', flexWrap: 'wrap' }}>
        <div style={{ flex: 1, minWidth: '280px' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '12px', marginBottom: '8px', flexWrap: 'wrap' }}>
            <h1 style={{
              fontFamily: 'DM Serif Display, serif',
              fontSize: '36px',
              fontWeight: 400,
              color: 'var(--text-primary)',
              margin: 0,
              lineHeight: 1.1,
            }}>
              {member.official_full}
            </h1>
            <span className={`badge-${member.party_code}`} style={{
              padding: '4px 10px', borderRadius: '20px', fontSize: '12px',
              fontWeight: 500, fontFamily: 'DM Sans', whiteSpace: 'nowrap',
            }}>
              {partyLabel}
            </span>
          </div>
          <div style={{
            display: 'flex', gap: '16px', flexWrap: 'wrap',
            fontSize: '13px', color: 'var(--text-secondary)', fontFamily: 'DM Sans',
          }}>
            <span>
              <span style={{ color: 'var(--text-muted)' }}>State: </span>
              {member.state_abbrev}
              {member.district_code ? `-${String(member.district_code).padStart(2, '0')}` : ''}
            </span>
            {member.terms_served != null && (
              <span>
                <span style={{ color: 'var(--text-muted)' }}>Terms: </span>
                {member.terms_served}
              </span>
            )}
            {member.age_in_2024 != null && (
              <span>
                <span style={{ color: 'var(--text-muted)' }}>Age: </span>
                {member.age_in_2024}
              </span>
            )}
            <span>
              <span style={{ color: 'var(--text-muted)' }}>@</span>
              {handle}
            </span>
          </div>
          {caucuses.length > 0 && (
            <div style={{ display: 'flex', gap: '6px', flexWrap: 'wrap', marginTop: '10px' }}>
              {caucuses.map(({ key, label }) => (
                <span key={key} style={{
                  padding: '3px 10px', borderRadius: '12px', fontSize: '11px',
                  background: 'var(--surface)', border: '1px solid var(--border)',
                  color: 'var(--text-secondary)', fontFamily: 'DM Sans',
                }}>
                  {label}
                </span>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Key stats */}
      <div style={{
        display: 'grid',
        gridTemplateColumns: 'repeat(auto-fit, minmax(160px, 1fr))',
        gap: '12px',
        marginBottom: '40px',
      }}>
        <StatTile
          label="Small Donor %"
          value={`${fmt(member.pct_small_donors, 1)}%`}
          sub={`Virality quartile: ${member.quartile ?? '—'}`}
          highlight
        />
        <StatTile
          label="Avg Retweets"
          value={fmt(member.avg_retweets_raw, 0)}
          sub={`${fmt(member.tweet_count, 0)} tweets analyzed`}
        />
        <StatTile
          label="Outrage Index"
          value={fmt(member.outrage_index, 3)}
        />
        <StatTile
          label="Avg Sentiment"
          value={fmt(member.avg_sentiment, 3)}
          sub={<span style={{ color: sentimentDir.color }}>{sentimentDir.label}</span>}
        />
        <StatTile
          label="Ideology |DW|"
          value={fmt(member.nominate_abs, 3)}
          sub={member.nominate_dim1 != null ? `DW-1: ${fmt(member.nominate_dim1, 3)}` : null}
        />
        <StatTile
          label="Followers"
          value={member.followers != null
            ? member.followers >= 1e6
              ? `${(member.followers / 1e6).toFixed(1)}M`
              : member.followers >= 1e3
              ? `${(member.followers / 1e3).toFixed(0)}K`
              : fmt(member.followers, 0)
            : '—'}
        />
      </div>

      {/* Main content: two columns */}
      <div style={{
        display: 'grid',
        gridTemplateColumns: '1fr 1fr',
        gap: '40px',
        alignItems: 'start',
      }}>
        {/* Left column */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: '40px' }}>

          {/* Emotion radar */}
          <Section title="Emotional Tone">
            <div style={{
              background: 'var(--surface)',
              border: '1px solid var(--border)',
              borderRadius: '12px',
              padding: '20px',
            }}>
              <EmotionRadar member={member} />
            </div>
          </Section>

          {/* Tone breakdown */}
          <Section title="Tone Breakdown">
            <div style={{
              background: 'var(--surface)',
              border: '1px solid var(--border)',
              borderRadius: '12px',
              padding: '20px',
              display: 'flex',
              flexDirection: 'column',
              gap: '10px',
            }}>
              {[
                { label: 'Positive tweets', value: member.pct_positive, color: '#4ade80' },
                { label: 'Negative tweets', value: member.pct_negative, color: '#f87171' },
                { label: 'Neutral tweets',  value: member.pct_neutral,  color: 'var(--text-muted)' },
                { label: 'Extreme negative', value: member.pct_extreme_neg, color: '#ef4444' },
              ].map(({ label, value, color }) => (
                <div key={label} style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                  <span style={{ width: '120px', fontSize: '12px', color: 'var(--text-secondary)', textAlign: 'right' }}>
                    {label}
                  </span>
                  <div style={{ flex: 1, height: '6px', background: 'var(--border)', borderRadius: '3px', overflow: 'hidden' }}>
                    <div style={{
                      width: `${((value ?? 0) * 100).toFixed(1)}%`,
                      height: '100%', background: color, borderRadius: '3px',
                    }} />
                  </div>
                  <span style={{ width: '44px', fontSize: '11px', fontFamily: 'JetBrains Mono', color: 'var(--text-secondary)' }}>
                    {fmt((value ?? 0) * 100, 1)}%
                  </span>
                </div>
              ))}
            </div>
          </Section>

          {/* Historical funding */}
          <Section title="Small-Donor Funding by Cycle">
            <div style={{
              background: 'var(--surface)',
              border: '1px solid var(--border)',
              borderRadius: '12px',
              padding: '20px',
            }}>
              <CycleChart member={member} />
              {member.pct_change_22_24 != null && (
                <div style={{ marginTop: '12px', fontSize: '12px', color: 'var(--text-secondary)' }}>
                  Change 2022→2024:{' '}
                  <span style={{ color: member.pct_change_22_24 >= 0 ? '#4ade80' : '#f87171', fontFamily: 'JetBrains Mono' }}>
                    {member.pct_change_22_24 >= 0 ? '+' : ''}{fmt(member.pct_change_22_24, 1)} pp
                  </span>
                </div>
              )}
            </div>
          </Section>

        </div>

        {/* Right column: top tweets */}
        <Section title={`Top Tweets by Retweets`}>
          <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
            {(member.top_tweets ?? []).length === 0 ? (
              <p style={{ color: 'var(--text-muted)', fontSize: 13 }}>No tweet data available.</p>
            ) : (
              member.top_tweets.map((tweet, i) => (
                <TweetCard key={tweet.Tweet_ID ?? i} tweet={tweet} />
              ))
            )}
          </div>
        </Section>

      </div>
    </div>
  )
}
