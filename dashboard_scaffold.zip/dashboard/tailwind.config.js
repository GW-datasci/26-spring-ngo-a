/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      fontFamily: {
        display: ['"DM Serif Display"', 'Georgia', 'serif'],
        body: ['"DM Sans"', 'sans-serif'],
        mono: ['"JetBrains Mono"', 'monospace'],
      },
      colors: {
        bg: '#0b0f1a',
        surface: '#131929',
        border: '#1e2d45',
        'text-primary': '#e8eef7',
        'text-secondary': '#6b7fa3',
        dem: '#4a8ff5',
        rep: '#e8433a',
        ind: '#a78bfa',
        gold: '#f0b429',
      },
    },
  },
  plugins: [],
}
