import { Routes, Route, Navigate } from 'react-router-dom'
import Nav from './components/Nav'
import Explore from './pages/Explore'
import Member from './pages/Member'

export default function App() {
  return (
    <div className="min-h-screen flex flex-col bg-bg text-ink">
      <Nav />
      <main className="flex-1">
        <Routes>
          <Route path="/" element={<Navigate to="/explore" replace />} />
          <Route path="/explore" element={<Explore />} />
          <Route path="/member/:handle" element={<Member />} />
        </Routes>
      </main>
    </div>
  )
}
